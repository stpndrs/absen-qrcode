<?php 
date_default_timezone_set("Asia/Ujung_Pandang");
$servername ="localhost";
$username ="root";
$conn = mysqli_connect($servername,$username,"","absensi_siswa");
?>